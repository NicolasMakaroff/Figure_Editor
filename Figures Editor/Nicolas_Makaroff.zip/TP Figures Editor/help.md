# Figure Editor

Pour créer une figure la procedure est indiqué en bas de la fenêtre.
Afin d'accéder au transformationListerner :
__MOVE__ : clic gauche + dragger
__SHAPE__: shift + clic droit
__ROTATION__: control + clic droit

## Etat de fonctionnement

__Historique__ : le undo enlève deux figures d'un coup et le redo les remet.

__InfoFrame__ : Les informations sur une figure n'apparaissent que lorsqu'une fois positionner sur la figure, on change de page (command+tab sur mac//alt+tab). L'affichage n'est pas bien réalisé non plus. J'ai volontairement laissé les nones pour montrer que le panel a bien été édité mais cela peut ne pas être évident au vu du problème évoqué plus haut.

__Filter__: la fonction marche mais peut-être pas comme attendue, je n'ai pas très bien compris son fonctionnement.