package figures.listeners.transform;

import java.awt.event.MouseEvent;

import javax.swing.JLabel;

import figures.Drawing;
import figures.Figure;
import history.HistoryManager;

public class TransformShapeListener extends AbstractTransformShapeListener {

	public TransformShapeListener(Drawing model, HistoryManager<Figure> history, JLabel tipLabel) {
		super(model, history, tipLabel);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateDrag(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
