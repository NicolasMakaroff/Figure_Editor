/**
 * Package contenant les différents enums pour l'UI
 * @author davidroussel
 */
package widgets.enums;
