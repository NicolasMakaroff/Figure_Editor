/**
 * Listeners spécialisés dans la création de nouvelles figures
 * @author davidroussel
 */
package figures.listeners.creation;
