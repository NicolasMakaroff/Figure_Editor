/**
 * Package contenant les différents Mouse[Motion]Listeners utilisés pour gérer
 * les évènement souris pour créer ou modifier des figures.
 * @author davidroussel
 */
package figures.listeners;
