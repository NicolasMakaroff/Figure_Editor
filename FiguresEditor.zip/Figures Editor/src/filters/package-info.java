/**
 * Package contenant les différents filtres à appliquer sur un flux de
 * figures
 * @author davidroussel
 */
package filters;
