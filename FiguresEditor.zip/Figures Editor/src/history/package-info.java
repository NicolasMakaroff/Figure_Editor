/**
 * Package contenant les classes nécessaire à l'implémentation d'un
 * système de Undo/Redo en utilisant le design pattern Memento
 * @author davidroussel
 */
package history;
